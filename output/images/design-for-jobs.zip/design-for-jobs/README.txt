These files are based on a Pen created at CodePen.io. 
You can find this one at https://codepen.io/tylersticka/pen/wJyprm.

[Explanatory Blog Post →](https://cloudfour.com/thinks/first-css-grid-layout/)